﻿namespace EmployeeTestBDDSpecflow.Model
{
    public class Data
    {
        public string name { get; set; }
        public int salary { get; set; }
        public int age { get; set; }
        public int id { get; set; }
    }

    public class EmployeeResponse
    {
        public string status { get; set; }
        public Data data { get; set; }
        public string message { get; set; }
    }

}
