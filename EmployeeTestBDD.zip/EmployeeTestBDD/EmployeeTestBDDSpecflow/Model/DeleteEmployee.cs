﻿namespace EmployeeTestBDDSpecflow.Model
{
   
   public class DeleteEmployee
    {
        public string status { get; set; }
        public string data { get; set; }
        public string message { get; set; }

    }


}
