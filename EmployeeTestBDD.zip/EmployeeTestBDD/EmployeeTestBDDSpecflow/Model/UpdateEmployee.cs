﻿namespace EmployeeTestBDDSpecflow.Model
{
   public class UpdateEmployee
    {
        public int id { get; set; }
        public string name { get; set; }
        public int salary { get; set; }
        public int age { get; set; }
    }
}
