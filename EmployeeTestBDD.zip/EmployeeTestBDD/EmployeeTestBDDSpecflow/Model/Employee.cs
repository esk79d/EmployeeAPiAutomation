﻿
namespace EmployeeTestBDDSpecflow.Model
{
    public class Employee
    {
        public string name { get; set; }
        public int salary { get; set; }
        public int age { get; set; }
    }
}
