﻿namespace EmployeeTestBDDSpecflow.Model
{   
        public class EmpDetails
        {
            public string employee_name { get; set; }
            public int employee_salary { get; set; }
            public int employee_age { get; set; }
            public int id { get; set; }
        }

        public class EmployeeDetailsResponse
        {
            public string status { get; set; }
            public EmpDetails data { get; set; }
            public string message { get; set; }
        }
    }

