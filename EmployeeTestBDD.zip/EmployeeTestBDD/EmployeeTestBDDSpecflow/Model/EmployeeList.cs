﻿using System.Collections.Generic;

namespace EmployeeTestBDD.Model
{
    public class EmpDetails
    {
        public int id { get; set; }
        public string employee_name { get; set; }
        public int employee_salary { get; set; }
        public int employee_age { get; set; }
        public string profile_image { get; set; }
    }

    public class EmployeeList
    {
        public string status { get; set; }
        public List<EmpDetails> data { get; set; }
        public string message { get; set; }
    }
}
