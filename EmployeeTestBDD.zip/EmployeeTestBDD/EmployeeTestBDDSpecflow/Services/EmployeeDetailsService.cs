﻿using EmployeeTestBDD.Model;
using EmployeeTestBDD.Utils;
using EmployeeTestBDDSpecflow.Model;
using Newtonsoft.Json;


namespace EmployeeTestBDD.Services
{
    public class EmployeeDetailsService
    {
        private const string getEmployeeListEndPoint = "https://dummy.restapiexample.com/api/v1/employees";
        string getEmployeeDetailsEndPoint = "https://dummy.restapiexample.com/api/v1/employee/";
        private const string createEmployeeEndPoint = "http://dummy.restapiexample.com/api/v1/create";
        private const string updateEmployeeEndPoint = "http://dummy.restapiexample.com/api/v1/update/";
        private const string deleteEmployeeEndPoint = "http://dummy.restapiexample.com/api/v1/delete/";

        // public async Task<EmployeeList> GetEmployeeList()
        public EmployeeList GetEmployeeList()
        {
            
            RestClient restClientObj = new();            
            var jsonData =  restClientObj.GetAsync(getEmployeeListEndPoint).Result;
            if (jsonData != null)
            {
                var employeeListObj = JsonConvert.DeserializeObject<EmployeeList>(jsonData);
                return employeeListObj;
            }
            return null;
        }

        public EmployeeDetailsResponse GetEmployeeDetails(int id)
        {

            RestClient restClientObj = new();
            
            var jsonData = restClientObj.GetAsync(getEmployeeDetailsEndPoint+id).Result;
            if (jsonData != null)
            {
                var employeeObj = JsonConvert.DeserializeObject<EmployeeDetailsResponse>(jsonData);
                return employeeObj;
            }
            return null;
        }
        public EmployeeResponse CreateEmployee(Employee employee)
        {
            RestClient restClientObj = new();
            var jsonData = restClientObj.PostAsync(createEmployeeEndPoint, employee).Result;
            if (jsonData != null)
            {
                var employeeObj = JsonConvert.DeserializeObject<EmployeeResponse>(jsonData);
                return employeeObj;
            }
            return null;
        }

        public EmployeeResponse UpdateEmp(UpdateEmployee employee)
        {
            RestClient restClientObj = new();
            var jsonData = restClientObj.PutAsync(updateEmployeeEndPoint, employee).Result;
            if (jsonData != null)
            {
                var employeeObj = JsonConvert.DeserializeObject<EmployeeResponse>(jsonData);
                return employeeObj;
            }
            return null;
        }

        public DeleteEmployee DeleteEmpDetails(int id)
        {
            RestClient restClientObj = new();
            var jsonData = restClientObj.DeleteAsync(deleteEmployeeEndPoint+id).Result;
            if (jsonData != null)
            {
                var employeeObj = JsonConvert.DeserializeObject<DeleteEmployee>(jsonData);
                return employeeObj;
            }
            return null;
        }
    }
}
