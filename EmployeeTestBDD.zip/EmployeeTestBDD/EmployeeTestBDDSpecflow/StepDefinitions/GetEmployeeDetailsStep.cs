﻿using EmployeeTestBDD.Services;
using EmployeeTestBDDSpecflow.Model;
using FluentAssertions;
using TechTalk.SpecFlow;

namespace EmployeeTestBDDSpecflow.StepDefinitions
{
    [Binding]
    class GetEmployeeDetailsStep
    {
        private readonly ScenarioContext _scenarioContext;

        public GetEmployeeDetailsStep(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }
        [When(@"we query for a particular Employee Details with Id (.*)")]
        public void WhenWeQueryForAParticularEmployeeDetailsWithId(int id)
        {
            EmployeeDetailsService employeeDetailsService = new();
            var result = employeeDetailsService.GetEmployeeDetails(id);
            _scenarioContext.Set(result, "response");
        }

        [Then(@"We should be able to view the correct employee details like ""(.*)"", (.*) and (.*)")]
        public void ThenWeShouldBeAbleToViewTheCorrectEmployeeDetailsLikeAnd(string name, int age, int salary)
        {
            var responseData = _scenarioContext.Get<EmployeeDetailsResponse>("response");            
            responseData.data.employee_age.Should().Equals(age);            
            responseData.data.employee_name.Should().Equals(name);
            responseData.data.employee_salary.Should().Equals(salary);
        }

    }
}
