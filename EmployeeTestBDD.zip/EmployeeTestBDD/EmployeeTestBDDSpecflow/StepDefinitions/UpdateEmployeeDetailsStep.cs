﻿using EmployeeTestBDD.Services;
using EmployeeTestBDDSpecflow.Model;
using FluentAssertions;

using TechTalk.SpecFlow;

namespace EmployeeTestBDDSpecflow.StepDefinitions
{
    [Binding]
    public class UpdateEmployeeDetailsStep
    {
        public UpdateEmployee _employee;

        private readonly ScenarioContext _scenarioContext;
        public UpdateEmployeeDetailsStep(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given(@"We've an existing employee (.*), ""(.*)"", (.*) and (.*)")]
        public void GivenWeVeAnExistingEmployeeAnd(int empId, string empName, int empAge, int empSalary)
        {
            _employee = new UpdateEmployee { id = empId, name = empName, age = empAge, salary = empSalary };            
            _scenarioContext.Set(_employee, "employeeDetails");
        }
     
        [Given(@"we are trying to update with valid details  ""(.*)"", (.*) and (.*)")]
        public void GivenWeAreTryingToUpdateWithValidDetailsAnd(string newName, int newAge, int newSalary)
        {
            _employee.name = newName;
            _employee.age = newAge;
            _employee.salary = newSalary;
            UpdateEmployee _newEmployeeDetails;
            _newEmployeeDetails = _employee;            
            _scenarioContext.Set(_newEmployeeDetails, "newEmployeeDetails");
        }


        [When(@"We call the UpdateEmployeeService")]
        public void WhenWeCallTheUpdateEmployeeService()
        {
            EmployeeDetailsService employeeDetailsService = new();            
            _scenarioContext.Set(employeeDetailsService.UpdateEmp(_scenarioContext.Get<UpdateEmployee>("employeeDetails")), "response");
        }

        [Then(@"an existing Employee record should be Updated successfully")]
        public void ThenAnExistingEmployeeRecordShouldBeUpdatedSuccessfully()
        {
            var responseData = _scenarioContext.Get<EmployeeResponse>("response");
            responseData.status.Should().Equals("success");            
            responseData.message.Should().Equals("Successfully! Record has been updated");
            var empId = responseData.data.id;
            responseData.data.id.Should().BeGreaterThan(0);
            responseData.data.age.Should().Equals(_employee.age);
            responseData.data.name.Should().Equals(_employee.name);
            responseData.data.salary.Should().Equals(_employee.salary);
        }
    }
}
