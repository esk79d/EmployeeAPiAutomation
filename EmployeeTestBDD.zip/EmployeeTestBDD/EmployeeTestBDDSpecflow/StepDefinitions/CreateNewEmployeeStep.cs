﻿using EmployeeTestBDD.Services;
using EmployeeTestBDDSpecflow.Model;
using FluentAssertions;
using TechTalk.SpecFlow;

namespace EmployeeTestBDDSpecflow.Steps
{
    [Binding]
    public sealed class CreateNewEmployeeStep
    {

        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext _scenarioContext;

        public CreateNewEmployeeStep(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }        

        [Given(@"The employee details is valid like ""(.*)"", ""(.*)"" and ""(.*)""")]
        public void GivenTheEmployeeDetailsIsValidLikeAnd(string empName, int empAge, int empSalary)
        {          
            Employee employee = new Employee { name = empName, age = empAge, salary = empSalary };
            _scenarioContext.Set(employee, "employeeDetails");     
        }

        [When(@"We call the CreateEmployeeService")]
        public void WhenWeCallTheCreateEmployeeService()
        {
            EmployeeDetailsService employeeDetailsService = new();
            _scenarioContext.Set(employeeDetailsService.CreateEmployee(_scenarioContext.Get<Employee>("employeeDetails")),"response");
        }

        [Then(@"a new Employee record should be Created")]
        public void ThenANewEmployeeRecordShouldBeCreated()
        {
            var responseData = _scenarioContext.Get<EmployeeResponse>("response");
            responseData.status.Should().Equals("success");
            responseData.message.Should().Equals("Successfully! Record has been added");
            responseData.data.id.Should().BeGreaterThan(0);
            responseData.data.age.Should().Equals(_scenarioContext.Get<Employee>("employeeDetails").age);
            responseData.data.name.Should().Equals(_scenarioContext.Get<Employee>("employeeDetails").name);
            responseData.data.salary.Should().Equals(_scenarioContext.Get<Employee>("employeeDetails").salary);            
        }
    }
}
