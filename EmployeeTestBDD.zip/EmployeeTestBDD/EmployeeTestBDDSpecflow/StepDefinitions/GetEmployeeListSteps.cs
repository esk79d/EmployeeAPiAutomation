﻿using EmployeeTestBDD.Model;
using EmployeeTestBDD.Services;
using FluentAssertions;
using TechTalk.SpecFlow;

namespace EmployeeTestBDD.StepDefinitions
{
    [Binding]
   public class GetEmployeeListSteps
    {
        private readonly ScenarioContext _scenarioContext;

        public GetEmployeeListSteps(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [When(@"we query for Employee List Details")]
        public void WhenWeQueryForEmployeeListDetails()
        {
            EmployeeDetailsService employeeDetailsService = new();
            var result = employeeDetailsService.GetEmployeeList();
            _scenarioContext.Set(result, "response");
        }

        [Then(@"We should be able to view all the employee details")]
        public void ThenWeShouldBeAbleToViewAllTheEmployeeDetails()
        {
            var responseData = _scenarioContext.Get<EmployeeList>("response");
            responseData.status.Should().Equals("success");
            responseData.message.Should().Equals("Successfully! All records has been fetched.");
            responseData.data.Count.Should().BeGreaterThan(1);
            responseData.data.Count.Should().Equals(24);
        }
    }
}
