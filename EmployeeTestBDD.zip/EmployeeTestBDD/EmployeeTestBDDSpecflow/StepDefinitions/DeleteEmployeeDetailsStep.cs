﻿using EmployeeTestBDD.Services;
using EmployeeTestBDDSpecflow.Model;
using FluentAssertions;
using TechTalk.SpecFlow;

namespace EmployeeTestBDDSpecflow.StepDefinitions
{
    [Binding]
    public class DeleteEmployeeDetailsStep
    {
        private readonly ScenarioContext _scenarioContext;
        public DeleteEmployeeDetailsStep(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }
        [When(@"we send a request to delete a particular Employee record with Id (.*)")]
        public void WhenWeSendARequestToDeleteAParticularEmployeeRecordWithId(int empId)
        {            
            EmployeeDetailsService employeeDetailsService = new();
            _scenarioContext.Set(employeeDetailsService.DeleteEmpDetails(empId), "response");
        }

        [Then(@"We should be able to delete the details successfully")]
        public void ThenWeShouldBeAbleToDeleteTheDetailsSuccessfully()
        {            
                var responseData = _scenarioContext.Get<DeleteEmployee>("response");
                responseData.status.Should().Equals("success");
                responseData.message.Should().Equals("Successfully! Record has been deleted");            
        }       
    }
}
