﻿using EmployeeTestBDDSpecflow.Model;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeTestBDD.Utils
{ 
    public class RestClient
    {
        public async Task<string> GetAsync(string url)
        {
            HttpClient client = new();
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Accept.Add(MediaTypeWithQualityHeaderValue.Parse("application/json"));
            var response =await  client.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                return string.Empty;
            }
            var data = await response.Content.ReadAsStringAsync();
            return data;
        }

        public async Task<string> PostAsync(string url, Employee employee)
        {
            HttpClient client = new();
            var data = JsonConvert.SerializeObject(employee, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore});
            var content = new StringContent(data, Encoding.UTF8, "application/json");
            var response= await client.PostAsync(url, content);            
            
            var dataobj = await response.Content.ReadAsStringAsync();
            return dataobj;
        }

        public async Task<string> PutAsync(string url, UpdateEmployee employee)
        {
            HttpClient client = new();
            var data = JsonConvert.SerializeObject(employee, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            var content = new StringContent(data, Encoding.UTF8, "application/json");
            var response = await client.PutAsync(url+ employee.id, content);            
            var dataobj = await response.Content.ReadAsStringAsync();
            return dataobj;
        }

        public async Task<string> DeleteAsync(string url)
        {
            HttpClient client = new();
            var request = new HttpRequestMessage(HttpMethod.Delete, url);
            request.Headers.Accept.Add(MediaTypeWithQualityHeaderValue.Parse("application/json"));
            var response = await client.DeleteAsync(url);
            if (!response.IsSuccessStatusCode)
            {
                return string.Empty;
            }
            var data = await response.Content.ReadAsStringAsync();
            return data;
        }
    }
}
